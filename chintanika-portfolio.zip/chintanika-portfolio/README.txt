CHINTANIKA JOSHI — PORTFOLIO WEBSITE

1. Extract the ZIP folder.
2. Open index.html in Chrome to view the site.
3. Open index.html in VS Code to edit text.
4. Search for your.email@example.com and replace BOTH occurrences with your email.
5. Replace https://www.linkedin.com/ with your actual LinkedIn profile URL.
6. The contact form opens the visitor's email app. It does NOT send messages directly from the website. To receive form submissions without an email app, connect a form service or backend.
7. Optional: add your PDF resume and a resume link in index.html.
8. Publish with GitHub Pages or Netlify when ready.

Files: index.html, style.css, script.js
Fonts load from Google Fonts and need an internet connection; fallback fonts are available.
